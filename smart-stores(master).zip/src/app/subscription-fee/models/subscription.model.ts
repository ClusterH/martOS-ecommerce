export interface SubscriptionData {
  id?: number;
  date: string;
  invoiceNumber: string;
  stores: string;
  priceExclT: number;
}
