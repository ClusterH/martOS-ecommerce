export type Bank = {
    bankName: string;
    bic: string;
    iban: string;
    ownerName: string;
    holderName: string;
    bankCity: string;
};