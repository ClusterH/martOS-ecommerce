export type DeleteCardRequest = {
    id: string;
};