export type GetChainByIdRequest = {
    id: number;
};