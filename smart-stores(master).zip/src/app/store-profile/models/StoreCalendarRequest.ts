export type StoreCalendarRequest = {
    referenceStoreId: string;
    country: string;
};