export type UpdateStoreNameRequest = {
  id: number;
  name: string;
  refStoreId: string;
}
