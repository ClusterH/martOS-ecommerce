export interface CardInfo {
  id: string;
  number: string;
  expiry: string;
}
