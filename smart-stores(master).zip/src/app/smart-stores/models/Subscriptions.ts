
export type Subscriptions = {
    type: string;
    price: number;
};