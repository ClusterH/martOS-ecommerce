export type User = {
    name: string;
    userName: string;
    email:string;
    familyName: string;
    phoneNumber: string;
    password: string;
};
