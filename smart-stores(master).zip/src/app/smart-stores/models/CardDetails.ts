import { Card } from "./Card";

export type CardDetails = {
    shopperEmail?: string;
    card: Card;
};
