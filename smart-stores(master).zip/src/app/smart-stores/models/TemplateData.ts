export type TemplateData = {
    id: number;
    name: string;
};