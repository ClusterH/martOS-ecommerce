import { Store } from "./Store";

export type ChainStore = {
    name: string;
    store: Store;
};