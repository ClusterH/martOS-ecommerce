export type LoginInputModel = {
    Username: string;
    Password: string;
    RememberLogin: boolean;
    ReturnUrl: string;
};