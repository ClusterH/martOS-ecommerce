
export interface PresImage {
    itemId: number;
    url: string;
}
