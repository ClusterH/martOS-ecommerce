export interface OnlineRequest {
    itemId: number;
    status: boolean;
    storeId: number;
}
