export enum LiveStatus {
    online = 'Online',
    offline = 'Offline'
}
