export enum PropertyType {
    name,
    brand,
    category,
    option
}
