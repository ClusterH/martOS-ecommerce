export interface response {
    success: boolean;
}
