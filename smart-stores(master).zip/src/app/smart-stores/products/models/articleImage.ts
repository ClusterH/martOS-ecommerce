
export type ArticleImage = {
    id: string;
    image: string;
    toDelete: boolean;
};