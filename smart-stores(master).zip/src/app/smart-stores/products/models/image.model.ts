export interface Images {
  referenceStoreId: string;
  itemId: number;
  articleGroupId: number;
  country: string;
  images64: string[];
}
