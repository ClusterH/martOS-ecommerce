/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ArrayJoinPipe } from './array-join.pipe';

describe('Pipe: ArrayJoine', () => {
  it('create an instance', () => {
    let pipe = new ArrayJoinPipe();
    expect(pipe).toBeTruthy();
  });
});
