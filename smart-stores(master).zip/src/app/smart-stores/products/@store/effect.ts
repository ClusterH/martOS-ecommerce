import { ProductsEffects } from './products/products.effect';

export const effects: any[] = [
  ProductsEffects
];

export * from './products/products.effect';
