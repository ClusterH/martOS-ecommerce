export function round(value: number) {
  return Math.round(value * 100) / 100;
}
