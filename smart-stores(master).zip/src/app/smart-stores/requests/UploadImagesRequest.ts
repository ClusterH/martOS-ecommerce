import { Images } from "../products/models";

export interface UploadImagesRequest {
    images: Images;
}
