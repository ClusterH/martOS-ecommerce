export type DeleteProductRequest = {
    id: number;
    storeId : number;
};