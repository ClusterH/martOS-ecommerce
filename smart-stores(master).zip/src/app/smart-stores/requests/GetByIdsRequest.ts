export type GetByIdsRequest = {
    articleIds: Number[];
};