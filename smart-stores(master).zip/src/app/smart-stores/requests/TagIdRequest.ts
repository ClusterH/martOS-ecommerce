export type TagIdRequest = {
    id: number;
    isToDelete: boolean;
};