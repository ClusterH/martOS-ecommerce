export type DeleteImageRequest = {
    ids: string[];
    refStoreId: string;
    country :string;
};