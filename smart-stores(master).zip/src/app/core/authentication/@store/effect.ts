import { AuthEffects } from './auth';

export const effects: any[] = [
    AuthEffects,
];

export * from './auth/auth.effect';
