export interface UserStaffStoreRequestModule {
  userId: string;
  referenceStoreId: string;
}
