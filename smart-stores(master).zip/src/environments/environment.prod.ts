export const environment = {
  production: true,
  authApiURI: 'http://51.140.48.107:8080/api',
  dataStoreApiURI: 'http://23.100.50.205:5000/api',
};
